<div class="contenedor login">
    <?php include_once __DIR__ . '/../templates/nombre-sitio.php' ?>

    <div class="contenedor-sm">
        <p class="descripcion-pagina">Panel de Administración</p>

        
    </div><!-- .contenedor-sm  -->
</div>