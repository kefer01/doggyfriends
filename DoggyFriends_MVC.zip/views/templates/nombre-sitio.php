<h1 class="uptask">Doggy Friends</h1>
<p class="tagline">Inicia Sesión para empezar a adoptar</p>